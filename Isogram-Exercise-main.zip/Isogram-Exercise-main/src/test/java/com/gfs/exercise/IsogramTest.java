package com.gfs.exercise;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class IsogramTest {

    @Test
    public void shouldTestSomething() {
        assertTrue(true);

    }
}
